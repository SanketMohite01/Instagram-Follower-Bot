from selenium import webdriver
from selenium.common.exceptions import ElementClickInterceptedException, NoSuchElementException
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

USERNAME = "_adiii_.07._"
PASSWORD = "ayush@1818"
SIMILAR_ACCOUNT = "cartoonnetworkindia"

class InstaFollower:
    def __init__(self):
        options = webdriver.ChromeOptions()
        options.add_experimental_option("detach", True)
        self.driver = webdriver.Chrome(options=options)
        self.wait = WebDriverWait(self.driver, 15)

    def login(self):
        self.driver.get("https://www.instagram.com/accounts/login/")
        self.driver.maximize_window()

        # Wait for input boxes to load
        try:
            self.wait.until(EC.presence_of_element_located((By.NAME, "username")))
        except:
            print("⚠️ Login fields not found. Trying again after short wait...")
            time.sleep(5)

        try:
            self.driver.find_element(By.NAME, "username").send_keys(USERNAME)
            self.driver.find_element(By.NAME, "password").send_keys(PASSWORD)
            self.driver.find_element(By.NAME, "password").send_keys(Keys.ENTER)
        except NoSuchElementException:
            print("❌ Could not find login fields.")
            return

        # Dismiss popups
        time.sleep(5)
        try:
            not_now1 = self.driver.find_element(By.XPATH, "//button[contains(text(), 'Not now')]")
            not_now1.click()
        except:
            pass
        time.sleep(2)
        try:
            not_now2 = self.driver.find_element(By.XPATH, "//button[contains(text(), 'Not Now')]")
            not_now2.click()
        except:
            pass

    def find_followers(self):
        self.driver.get(f"https://www.instagram.com/{SIMILAR_ACCOUNT}/")
        time.sleep(4)

        try:
            followers_link = self.driver.find_element(By.PARTIAL_LINK_TEXT, "followers")
            followers_link.click()
        except:
            print("❌ Could not find followers link.")
            return

        time.sleep(4)
        modal_xpath = "//div[@role='dialog']//div[@class='_aano']"
        try:
            modal = self.wait.until(EC.presence_of_element_located((By.XPATH, modal_xpath)))
            for i in range(5):
                self.driver.execute_script("arguments[0].scrollTop = arguments[0].scrollHeight", modal)
                time.sleep(2)
        except:
            print("❌ Followers modal not found.")

    def follow(self):
        time.sleep(2)
        follow_buttons = self.driver.find_elements(By.XPATH, "//button[normalize-space()='Follow']")

        for btn in follow_buttons:
            try:
                btn.click()
                print("✅ Followed one user.")
                time.sleep(1)
            except ElementClickInterceptedException:
                try:
                    cancel_btn = self.driver.find_element(By.XPATH, "//button[contains(text(), 'Cancel')]")
                    cancel_btn.click()
                    print("⚠️ Already followed, canceled dialog.")
                except:
                    pass

# --------- RUNNING THE BOT ---------
bot = InstaFollower()
bot.login()
bot.find_followers()
bot.follow()
